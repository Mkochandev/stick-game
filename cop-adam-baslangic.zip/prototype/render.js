/* Çizim yardımcıları: çöp adamlar, atış deseni simgeleri, tahta ve kayıt metinleri. */
(function () {
  'use strict';
  const O = window.Oyun;
  const { N, COLS, TYPES } = O;

  const HELMET = '<path class="f" d="M15.4 8.6a4.6 4.6 0 0 1 9.2 0z"/>';
  const ACC = {
    piyade: HELMET + '<path d="M20 16l-5 5M20 16l5 0"/><path class="gun" d="M11 23.6L31 12"/>',
    makineli: HELMET + '<path d="M20 16l4 4M20 16l7 2.4"/><path class="gun heavy" d="M13 20.2h22"/><path class="thin" d="M17 22l1.5 3 1.5-3 1.5 3 1.5-3"/>',
    havanci: HELMET + '<path d="M20 16l-8 5M20 16l-5 7"/><path class="gun heavy" d="M6 33.5L11.5 20"/><path d="M3 34h11"/><path class="thin" stroke-dasharray="1.5 2" d="M12 17q5-12 14-12"/>',
    keskin: '<path class="f" d="M16.6 6.6a3.4 3 0 0 1 6.8 0z"/><path d="M14.4 6.8h11.2" stroke-width="1.8"/><path d="M20 16l6 1M20 16l9 3"/><path class="gun" d="M10 20.4L38 16.4"/><rect class="f" x="22.5" y="14.6" width="7" height="2" rx="1" transform="rotate(-8 26 15.6)"/>',
    gozcu: '<path d="M20 16l-3.5 5M20 16l3.5 5"/><rect class="f" x="15.5" y="20.5" width="9" height="3" rx="1"/><path class="thin" d="M22.5 20.5l2-3"/><rect class="f" x="29.5" y="3.4" width="6" height="2.4" rx="1"/><path class="thin" d="M26.5 2.4h4M34.5 2.4h4M28.5 2.4v1.6M36.5 2.4v1.6"/>',
    komutan: '<path class="f" d="M15.6 7.2c0-2.6 1.8-3.8 4.4-3.8s4.4 1.2 4.4 3.8z"/><path d="M14.8 7.5h10.6" stroke-width="1.8"/><path d="M20 16l12-1M20 16l-4 4 2.5 2.5"/><path d="M32 34V6"/><path class="f" d="M32 6h7l-2.2 3 2.2 3h-7z"/>',
  };
  const EYES = '<path class="x" d="M17.7 9l1.6 1.6M19.3 9l-1.6 1.6M20.7 9l1.6 1.6M22.3 9l-1.6 1.6"/>';

  function fig(type, cls) {
    return `<svg class="fig ${cls || ''}" viewBox="0 0 40 40" aria-hidden="true"><g class="sk"><circle cx="20" cy="9" r="4.2"/><path d="M20 13.2V25M20 25l-5 9M20 25l5 9"/>${ACC[type] || ACC.piyade}${EYES}</g></svg>`;
  }
  const tile = (type, cls) => `<span class="tile">${fig(type, cls)}</span>`;

  function patMini(kind) {
    const T = TYPES[kind];
    const on = new Set(O.cellsFor(T.pattern, 2, 2, 'row').filter(([r, c]) => r < 5 && c < 5).map(([r, c]) => r * 5 + c));
    let h = '<span class="pat" aria-hidden="true">';
    for (let i = 0; i < 25; i++) h += `<i class="${on.has(i) ? (T.scan ? 'scan' : 'on') : ''}"></i>`;
    return h + '</span>';
  }

  const who = (game, a) => (game.mode === 'pve' ? (a === 0 ? 'Sen' : 'Düşman') : `Oyuncu ${a + 1}`);

  function logText(game, res) {
    if (res.kind === 'skip') return `${who(game, res.a)}: hazır silah yoktu, tur geçti.`;
    const def = game.sides[1 - res.a];
    const T = TYPES[res.kind];
    const target = res.kind === 'komutan' ? (res.orient === 'col' ? `${COLS[res.c]} sütunu` : `${res.r + 1}. satır`) : O.coord(res.r, res.c);
    const head = `${who(game, res.a)} · ${T.weapon} → ${target}: `;
    if (T.scan) return head + `bölgede ${res.hint.start} asker.`;
    let s = head + (res.kills.length ? res.kills.map((id) => TYPES[def.soldiers[id].type].name).join(', ') + ' düştü.' : 'ıska.');
    if (res.hint) s += ` Çevrede ${res.hint.start} asker var.`;
    return s;
  }

  function boardHTML(app, idx, role) {
    const g = app.game, side = g.sides[idx];
    const fx = app.fx && app.fx.side === idx && role !== 'place' ? app.fx : null;
    const marks = new Set(), badges = new Map();
    if (role !== 'place') {
      for (const h of side.hints) {
        for (const [r, c] of h.cells) marks.add(r * N + c);
        badges.set(h.r * N + h.c, h);
      }
    }
    const tag = role === 'own' ? 'span' : 'button';
    const label = role === 'target' ? 'Düşman hattı' : role === 'own' ? 'Senin hattın' : 'Yerleştirme alanı';
    let h = `<div class="board ${role}" role="group" aria-label="${label}"><span class="lab"></span>`;
    for (let c = 0; c < N; c++) h += `<span class="lab">${COLS[c]}</span>`;
    for (let r = 0; r < N; r++) {
      h += `<span class="lab">${r + 1}</span>`;
      for (let c = 0; c < N; c++) {
        const k = r * N + c, f = side.fired[r][c], s = O.soldierAt(side, r, c);
        const falling = fx && fx.kills.includes(k) ? ' falling' : '';
        let cls = 'cell', inner = '', state = '';
        if (role === 'target') {
          if (f === 1) { inner = '<span class="crater"></span>'; state = 'ıska'; }
          else if (f === 2 && s) { inner = fig(s.type, 'foe dead' + falling); state = TYPES[s.type].name + ' düştü'; }
          if (g.winner !== null && s && s.alive) { inner += fig(s.type, 'foe ghost'); state = TYPES[s.type].name + ' saklanıyordu'; }
        } else if (s) {
          inner = fig(s.type, 'ally' + (s.alive ? '' : ' dead' + falling));
          state = TYPES[s.type].name + (s.alive ? '' : ' düştü');
        } else if (f === 1) { inner = '<span class="crater"></span>'; state = 'ıska'; }
        if (marks.has(k)) cls += ' scanned';
        const b = badges.get(k);
        if (b) { inner += `<span class="badge ${b.kind}">${b.count}</span>`; state += (state ? ', ' : '') + `bölgede ${b.count} asker`; }
        if (fx && fx.cells.includes(k)) cls += fx.scan ? ' ping' : ' boom';
        const attrs = tag === 'button' ? ` type="button" data-r="${r}" data-c="${c}" aria-label="${O.coord(r, c)}${state ? ' · ' + state : ''}"` : '';
        h += `<${tag} class="${cls}"${attrs}>${inner}</${tag}>`;
      }
    }
    return h + '</div>';
  }

  window.Ciz = { fig, tile, patMini, who, logText, boardHTML };
})();
