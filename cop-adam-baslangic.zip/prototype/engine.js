/* Çöp Adam Amiral Battı — oyun kuralları ve bilgisayar zekâsı. Arayüzden bağımsız. */
(function () {
  'use strict';
  const N = 8;
  const COLS = 'ABCDEFGH';

  const TYPES = {
    piyade:   { name: 'Piyade',         weapon: 'Tüfek',          pattern: 'single', cd: 0, desc: '1 kare · her tur' },
    makineli: { name: 'Makineli',       weapon: 'Makineli tüfek', pattern: 'row3',   cd: 1, desc: 'Yan yana 3 kare · 2 turda bir' },
    havanci:  { name: 'Havancı',        weapon: 'Havan',          pattern: 'plus',   cd: 2, desc: 'Artı şeklinde 5 kare · 3 turda bir' },
    keskin:   { name: 'Keskin nişancı', weapon: 'Dürbünlü tüfek', pattern: 'single', cd: 1, sniper: true, desc: '1 kare; ıskalarsa çevresindeki asker sayısını söyler · 2 turda bir' },
    gozcu:    { name: 'Gözcü',          weapon: 'Drone',          pattern: 'box3',   cd: 2, scan: true, desc: 'Hasar vermez; 3×3 alandaki asker sayısını gösterir · 3 turda bir' },
    komutan:  { name: 'Komutan',        weapon: 'Hava desteği',   pattern: 'line',   cd: 0, once: true, desc: 'Bir satırın ya da sütunun tamamı · maçta 1 kez' },
    tabanca:  { name: 'Son direniş',    weapon: 'Tabanca',        pattern: 'single', cd: 0, desc: 'Son kalan asker her tur 1 kareye ateş eder' },
  };
  const STANDARD = ['piyade', 'makineli', 'havanci', 'keskin', 'gozcu', 'komutan'];

  const LEVELS = [
    { name: 'Acemi Birlik',  roster: ['piyade', 'piyade', 'piyade', 'piyade', 'piyade', 'makineli'], brain: 1, note: 'Beş tüfek, bir makineli. Rastgele ateş eder.' },
    { name: 'Devriye Timi',  roster: ['piyade', 'piyade', 'piyade', 'makineli', 'keskin', 'gozcu'], brain: 2, note: 'Keskin nişancı ve drone geldi. İpuçlarını takip eder.' },
    { name: 'Topçu Bölüğü',  roster: ['piyade', 'piyade', 'makineli', 'havanci', 'keskin', 'gozcu'], brain: 3, note: 'Havan geldi. Olasılık haritasıyla nişan alır.' },
    { name: 'Komando',       roster: STANDARD.slice(), brain: 4, note: 'Tam kadro ve hava desteği. Askerlerini dağıtarak saklar.' },
    { name: 'Elit Karargâh', roster: STANDARD.concat(['havanci']), brain: 5, note: 'Yedi asker, ikinci havan. Her atışı hesaplar.' },
  ];

  const grid = (v) => Array.from({ length: N }, () => Array(N).fill(v));
  const inside = (r, c) => r >= 0 && r < N && c >= 0 && c < N;
  const coord = (r, c) => COLS[c] + (r + 1);
  const rnd = (n) => Math.floor(Math.random() * n);
  const pick = (a) => a[rnd(a.length)];

  function cellsFor(pattern, r, c, orient) {
    const out = [];
    const add = (rr, cc) => { if (inside(rr, cc)) out.push([rr, cc]); };
    if (pattern === 'single') add(r, c);
    else if (pattern === 'row3') { add(r, c - 1); add(r, c); add(r, c + 1); }
    else if (pattern === 'plus') { add(r, c); add(r - 1, c); add(r + 1, c); add(r, c - 1); add(r, c + 1); }
    else if (pattern === 'box3') { for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) add(r + i, c + j); }
    else if (pattern === 'line') { for (let k = 0; k < N; k++) orient === 'col' ? add(k, c) : add(r, k); }
    return out;
  }

  function makeSide(roster) {
    return {
      soldiers: roster.map((type, id) => ({ id, type, r: -1, c: -1, alive: true, cd: 0, used: false })),
      fired: grid(0), // 0 bilinmiyor · 1 ıska · 2 asker düştü
      hints: [],      // rakibin bu tahtada elde ettiği bilgiler (drone, keskin nişancı)
    };
  }

  function newGame(mode, levelIndex) {
    const lvl = mode === 'pve' ? LEVELS[levelIndex] : null;
    return {
      mode, levelIndex: lvl ? levelIndex : -1,
      sides: [makeSide(STANDARD), makeSide(lvl ? lvl.roster : STANDARD)],
      turn: 0, round: 1, winner: null, log: [],
    };
  }

  const soldierAt = (side, r, c) => side.soldiers.find((s) => s.r === r && s.c === c) || null;
  const aliveOf = (side) => side.soldiers.filter((s) => s.alive);
  const aliveIn = (side, cells) => cells.filter(([r, c]) => { const s = soldierAt(side, r, c); return s && s.alive; }).length;

  function options(side) {
    const alive = aliveOf(side);
    const out = alive.filter((s) => s.cd === 0 && !(TYPES[s.type].once && s.used)).map((s) => ({ sid: s.id, kind: s.type }));
    if (alive.length === 1) out.push({ sid: alive[0].id, kind: 'tabanca' });
    return out;
  }

  function validTarget(def, kind, r, c, orient) {
    const T = TYPES[kind];
    if (T.scan) return inside(r, c);
    return cellsFor(T.pattern, r, c, orient).some(([rr, cc]) => def.fired[rr][cc] === 0);
  }

  function endTurn(game, a, choice) {
    const att = game.sides[a];
    for (const s of att.soldiers) if (s.cd > 0) s.cd -= 1;
    if (choice && choice.kind !== 'tabanca') {
      const s = att.soldiers[choice.sid];
      s.cd = TYPES[s.type].cd;
      if (TYPES[s.type].once) s.used = true;
    }
    game.turn = 1 - a;
    if (a === 1) game.round += 1;
  }

  function fire(game, a, choice, r, c, orient) {
    const def = game.sides[1 - a];
    const T = TYPES[choice.kind];
    const cells = cellsFor(T.pattern, r, c, orient);
    const res = { a, kind: choice.kind, sid: choice.sid, r, c, orient: orient || 'row', cells, kills: [], hint: null, round: game.round };
    if (T.scan) {
      const count = aliveIn(def, cells);
      res.hint = { kind: 'drone', r, c, cells, count, start: count };
      def.hints.push(res.hint);
    } else {
      for (const [rr, cc] of cells) {
        if (def.fired[rr][cc] !== 0) continue;
        const s = soldierAt(def, rr, cc);
        if (s && s.alive) {
          s.alive = false;
          def.fired[rr][cc] = 2;
          res.kills.push(s.id);
          for (const h of def.hints) if (h.cells.some(([hr, hc]) => hr === rr && hc === cc)) h.count = Math.max(0, h.count - 1);
        } else def.fired[rr][cc] = 1;
      }
      if (T.sniper && !res.kills.length) {
        const nb = cellsFor('box3', r, c).filter(([rr, cc]) => rr !== r || cc !== c);
        const count = aliveIn(def, nb);
        res.hint = { kind: 'sniper', r, c, cells: nb, count, start: count };
        def.hints.push(res.hint);
      }
    }
    endTurn(game, a, choice);
    game.log.push(res);
    if (!aliveOf(def).length) game.winner = a;
    return res;
  }

  function skip(game, a) {
    const res = { a, kind: 'skip', round: game.round, cells: [], kills: [] };
    endTurn(game, a, null);
    game.log.push(res);
    return res;
  }

  /* Yerleştirme. "smart" iken askerler aynı satır/sütuna ve yan yana düşmeyecek şekilde dağıtılır. */
  function placeRandom(side, smart) {
    const n = side.soldiers.length;
    let best = null, bestScore = Infinity;
    for (let t = 0; t < (smart ? 400 : 1); t++) {
      const pool = [...Array(N * N).keys()];
      const pos = [];
      for (let i = 0; i < n; i++) { const j = i + rnd(pool.length - i); [pool[i], pool[j]] = [pool[j], pool[i]]; pos.push(pool[i]); }
      let score = 0;
      if (smart) {
        for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
          const dr = Math.abs(Math.floor(pos[i] / N) - Math.floor(pos[j] / N)), dc = Math.abs((pos[i] % N) - (pos[j] % N));
          if (dr === 0) score += 3;
          if (dc === 0) score += 3;
          if (Math.max(dr, dc) <= 1) score += 5; else if (dr + dc <= 2) score += 2;
        }
      }
      if (score < bestScore) { bestScore = score; best = pos; }
    }
    side.soldiers.forEach((s, i) => { s.r = Math.floor(best[i] / N); s.c = best[i] % N; });
  }

  /* ---------- Bilgisayar zekâsı ---------- */

  function knowledge(def) {
    const U = [];
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (def.fired[r][c] === 0) U.push(r * N + c);
    const hints = def.hints.map((h) => ({ set: h.cells.filter(([r, c]) => def.fired[r][c] === 0).map(([r, c]) => r * N + c), count: h.count }));
    return { U, hints, n: aliveOf(def).length };
  }

  function uniformMap(def) {
    const p = new Float64Array(N * N);
    for (const x of knowledge(def).U) p[x] = 1;
    return p;
  }

  // Seviye 2: sıfır çıkan bölgelerden kaçınır, dolu çıkan bölgelere yönelir.
  function simpleMap(def) {
    const { U, hints } = knowledge(def);
    const p = new Float64Array(N * N);
    for (const x of U) p[x] = 1;
    for (const h of hints) for (const x of h.set) p[x] = h.count === 0 ? 0 : (p[x] > 0 ? 3 : 0);
    return p;
  }

  // Seviye 3+: bilinen ipuçlarıyla uyumlu rastgele yerleşimlerden kare başına olasılık çıkarır.
  function probMap(def) {
    const { U, hints, n } = knowledge(def);
    const p = new Float64Array(N * N);
    if (!U.length || !n) return p;
    const freq = new Float64Array(N * N);
    const mark = new Uint8Array(N * N);
    const pool = U.slice();
    let ok = 0;
    for (let t = 0; t < 9000 && ok < 700; t++) {
      for (let i = 0; i < n; i++) { const j = i + rnd(pool.length - i); [pool[i], pool[j]] = [pool[j], pool[i]]; mark[pool[i]] = 1; }
      let good = true;
      for (const h of hints) { let k = 0; for (const x of h.set) k += mark[x]; if (k !== h.count) { good = false; break; } }
      if (good) { ok++; for (let i = 0; i < n; i++) freq[pool[i]]++; }
      for (let i = 0; i < n; i++) mark[pool[i]] = 0;
    }
    if (ok >= 30) { for (const x of U) p[x] = freq[x] / ok; return p; }
    // Örnekleme yetmezse yaklaşık hesap
    const inHint = new Uint8Array(N * N), locals = Array.from({ length: N * N }, () => []);
    let hintSum = 0;
    for (const h of hints) {
      if (!h.set.length) continue;
      hintSum += h.count;
      for (const x of h.set) { inHint[x] = 1; locals[x].push(h.count / h.set.length); }
    }
    const free = U.filter((x) => !inHint[x]);
    const base = free.length ? Math.max(0.02, (n - hintSum) / free.length) : 0;
    for (const x of U) {
      const l = locals[x];
      p[x] = l.length ? (Math.min(...l) === 0 ? 0 : l.reduce((s, v) => s + v, 0) / l.length) : base;
    }
    return p;
  }

  function candidates(def, opts, p) {
    const out = [];
    for (const o of opts) {
      const T = TYPES[o.kind];
      if (T.scan) continue;
      const centers = [];
      if (T.pattern === 'line') for (let k = 0; k < N; k++) { centers.push([k, 0, 'row']); centers.push([0, k, 'col']); }
      else for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) centers.push([r, c, 'row']);
      for (const [r, c, orient] of centers) {
        let ev = 0, fresh = 0;
        for (const [rr, cc] of cellsFor(T.pattern, r, c, orient)) if (def.fired[rr][cc] === 0) { ev += p[rr * N + cc]; fresh++; }
        if (fresh) out.push({ o, r, c, orient, ev });
      }
    }
    return out;
  }

  function aiChoose(game, a, brain) {
    const att = game.sides[a], def = game.sides[1 - a];
    const opts = options(att);
    if (!opts.length) return null;
    const drone = opts.find((o) => o.kind === 'gozcu');
    const dmg = opts.filter((o) => o.kind !== 'gozcu');
    const unknown = knowledge(def).U.length;

    const scanAt = (p) => {
      let best = null, bv = -1;
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        let v = 0, u = 0;
        for (const [rr, cc] of cellsFor('box3', r, c)) if (def.fired[rr][cc] === 0) { const q = p ? p[rr * N + cc] : 0.5; v += q * (1 - q); u++; }
        if (u < 4) continue;
        v += Math.random() * 0.01;
        if (v > bv) { bv = v; best = [r, c]; }
      }
      return best && { choice: drone, r: best[0], c: best[1], orient: 'row' };
    };

    if (!dmg.length) return drone ? scanAt(null) : null;

    if (brain === 1) {
      const o = pick(dmg);
      const m = pick(candidates(def, [o], uniformMap(def)));
      return { choice: o, r: m.r, c: m.c, orient: m.orient };
    }

    if (brain === 2) {
      if (drone && unknown > 12 && Math.random() < 0.3) { const s = scanAt(null); if (s) return s; }
      const wide = dmg.filter((o) => TYPES[o.kind].pattern !== 'single');
      const o = wide.length && Math.random() < 0.6 ? pick(wide) : pick(dmg);
      const cands = candidates(def, [o], simpleMap(def)).sort((x, y) => y.ev - x.ev);
      const m = cands[rnd(Math.min(4, cands.length))];
      return { choice: o, r: m.r, c: m.c, orient: m.orient };
    }

    const p = probMap(def);
    let maxP = 0;
    for (const v of p) if (v > maxP) maxP = v;
    if (drone && unknown > 10 && maxP < (brain >= 5 ? 0.34 : 0.28) && (brain >= 4 || Math.random() < 0.6)) {
      const s = scanAt(p);
      if (s) return s;
    }
    const cost = { piyade: 0, tabanca: 0, keskin: -0.02, makineli: 0.03, havanci: 0.06, komutan: brain >= 4 ? 0.75 : 0.45 };
    const cands = candidates(def, dmg, p)
      .map((x) => ({ ...x, score: x.ev - (cost[x.o.kind] || 0) + Math.random() * 0.002 }))
      .sort((x, y) => y.score - x.score);
    let m = cands[0];
    if (brain === 3) {
      const roll = Math.random();
      m = cands[roll < 0.7 ? 0 : Math.min(roll < 0.9 ? 1 : 2, cands.length - 1)];
    }
    return { choice: m.o, r: m.r, c: m.c, orient: m.orient };
  }

  window.Oyun = {
    N, COLS, TYPES, STANDARD, LEVELS, coord, cellsFor, newGame, soldierAt, options,
    validTarget, fire, skip, placeRandom, aiChoose,
  };
})();
