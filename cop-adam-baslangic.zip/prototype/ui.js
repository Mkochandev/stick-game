/* Ekranlar, sıra akışı ve dokunma/klavye olayları. */
(function () {
  'use strict';
  const O = window.Oyun, D = window.Ciz;
  const { N, TYPES, LEVELS, STANDARD } = O;
  const $ = (s, el) => (el || document).querySelector(s);
  const screen = $('#screen'), statusEl = $('#status'), cover = $('#cover'), menuBtn = $('#menuBtn');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const T_AI = reduce ? 500 : 1000;

  const app = { view: 'menu', game: null, placeIdx: 0, pick: 0, sel: null, aim: null, orient: 'row', busy: false, viewer: 0, fx: null, note: '', lastRes: null };
  let timer = null, noteTimer = null, coverNext = null, leaveArmed = false;
  const later = (fn, ms) => { clearTimeout(timer); timer = setTimeout(fn, ms); };

  const KEY = 'copadam-ilerleme';
  function loadDone() { try { const v = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function saveDone(i) { try { const d = loadDone(); if (!d.includes(i)) { d.push(i); localStorage.setItem(KEY, JSON.stringify(d)); } } catch (e) { /* kayıt yoksa ilerleme gösterilmez */ } }

  /* ---------- Ekranlar ---------- */

  function setStatus() {
    const g = app.game;
    menuBtn.hidden = app.view === 'menu';
    if (!leaveArmed) { menuBtn.textContent = 'Menü'; menuBtn.classList.remove('primary'); }
    if (app.view === 'menu' || !g) { statusEl.innerHTML = ''; return; }
    const lvl = g.mode === 'pve' ? `Bölüm ${g.levelIndex + 1} · <b>${LEVELS[g.levelIndex].name}</b>` : `<b>Oyuncu ${(app.view === 'place' ? app.placeIdx : app.viewer) + 1}</b>`;
    if (app.view === 'place') { statusEl.innerHTML = `${lvl} · Yerleştirme`; return; }
    const turn = g.winner !== null ? 'Maç bitti' : g.turn === app.viewer && !app.busy ? 'Sıra sende' : g.mode === 'pve' ? 'Düşman nişan alıyor' : 'Sıra rakipte';
    statusEl.innerHTML = `${lvl} · Tur ${g.round} · <b>${turn}</b>`;
  }

  const kadroItem = (figType, kind) => `<li>${D.tile(figType, 'ally')}<div><b>${TYPES[kind].name} · ${TYPES[kind].weapon}</b><span class="d">${TYPES[kind].desc}</span></div>${D.patMini(kind)}</li>`;

  function renderMenu() {
    const done = loadDone();
    const next = LEVELS.findIndex((_, i) => !done.includes(i));
    const squad = STANDARD.map((t) => `<figure>${D.fig(t, 'ally')}<figcaption>${TYPES[t].name.split(' ')[0]}</figcaption></figure>`).join('');
    screen.innerHTML = `
    <section class="hero">
      <div>
        <p class="eyebrow">Oynanabilir prototip · 8×8 cephe</p>
        <h1>Askerini sakla, rakibin silahını düşür.</h1>
        <p class="lede">Askerlerini gizlice yerleştir, sırayla ateş edin. Her askerin bir silahı var; asker düşünce silahı da gider. Bütün askerlerini kaybeden kaybeder.</p>
      </div>
      <div class="squad">${squad}</div>
    </section>
    <section class="modes">
      <div class="mode">
        <div class="mode-head"><h2>Kampanya</h2><span class="tag">PvE · bilgisayara karşı</span></div>
        <p class="hint">Her bölümde düşmanın silahları güçlenir, nişancılığı keskinleşir.</p>
        <ol class="levels">${LEVELS.map((l, i) => `<li><button type="button" class="level${i === next ? ' next' : ''}" data-level="${i}">
          <span class="lv-num">${i + 1}</span>
          <span class="lv-body"><span class="lv-name">${l.name}${done.includes(i) ? '<span class="done">Geçildi</span>' : ''}</span>
            <span class="lv-note">${l.note}</span>
            <span class="lv-roster">${l.roster.map((t) => D.tile(t, 'foe')).join('')}</span></span>
          <span class="iq" aria-label="Zekâ ${l.brain}/5">Zekâ<span class="pips">${[1, 2, 3, 4, 5].map((n) => `<i class="${n <= l.brain ? 'on' : ''}"></i>`).join('')}</span></span>
        </button></li>`).join('')}</ol>
      </div>
      <div class="mode">
        <div class="mode-head"><h2>İki kişi</h2><span class="tag">PvP · aynı cihaz</span></div>
        <p class="hint">Sırayla oynayın; her atıştan sonra cihaz diğer oyuncuya geçer. Online sürümde rakip kendi telefonunda olacak.</p>
        <button type="button" class="btn primary" id="startPvp">Maçı başlat</button>
        <p class="tip">İki taraf da aynı altı kişilik kadroyla başlar. Önce Oyuncu 1, sonra Oyuncu 2 yerleştirir.</p>
      </div>
    </section>
    <section class="kadro">
      <h2>Kadro ve silahlar</h2>
      <ul>${STANDARD.map((t) => kadroItem(t, t)).join('')}${kadroItem('piyade', 'tabanca')}</ul>
    </section>`;
  }

  function renderPlace() {
    const g = app.game, side = g.sides[app.placeIdx];
    const left = side.soldiers.filter((s) => s.r < 0).length;
    screen.innerHTML = `
    <section class="place">
      <div>
        <div class="ph"><h2>${g.mode === 'pvp' ? `Oyuncu ${app.placeIdx + 1} · ` : ''}Askerlerini yerleştir</h2></div>
        ${D.boardHTML(app, app.placeIdx, 'place')}
      </div>
      <aside class="place-side">
        <p class="hint">Listeden bir asker seç, sonra tahtada bir kareye dokun. Yerleşmiş bir askere dokunursan onu geri alırsın.</p>
        <ul class="chips">${side.soldiers.map((s) => `<li><button type="button" class="chip${app.pick === s.id ? ' sel' : ''}${s.r >= 0 ? ' placed' : ''}" data-chip="${s.id}" aria-pressed="${app.pick === s.id}">${D.tile(s.type, 'ally')}<span><b>${TYPES[s.type].name}</b><small>${s.r >= 0 ? O.coord(s.r, s.c) : 'Yerleştirilmedi'}</small></span></button></li>`).join('')}</ul>
        <div class="row-btns"><button type="button" class="btn" id="shuffle">Rastgele dağıt</button><button type="button" class="btn ghost" id="clearPlace">Temizle</button></div>
        <button type="button" class="btn primary wide" id="ready"${left ? ' disabled' : ''}>${left ? `${left} asker kaldı` : 'Hazır'}</button>
        <p class="tip"><b>İpucu:</b> Askerlerini aynı satıra dizme; hava desteği bir satırı tek seferde siler. Yan yana duranları havan birlikte vurur.</p>
        ${g.mode === 'pve' ? `<p class="tip">Rakip: <b>${LEVELS[g.levelIndex].name}</b>. ${LEVELS[g.levelIndex].note}</p>` : ''}
      </aside>
    </section>`;
  }

  function aimLabel() {
    const [r, c] = app.aim;
    if (TYPES[app.sel.kind].pattern === 'line') return app.orient === 'col' ? `${O.COLS[c]} sütunu` : `${r + 1}. satır`;
    return O.coord(r, c);
  }

  function aimbarHTML(myTurn) {
    const g = app.game;
    const warn = app.note ? `<p class="warn">${app.note}</p>` : '';
    if (g.winner !== null) return '<p class="wait">Maç bitti. Gizli kalan askerler soluk görünüyor.</p><button type="button" class="btn primary" data-act="again">Tekrar oyna</button><button type="button" class="btn ghost" data-act="menu">Menü</button>';
    if (!myTurn) return `<p class="wait">${g.mode === 'pve' ? 'Düşman nişan alıyor…' : 'Sıra rakipte.'}</p>`;
    if (!app.sel) return warn || '<p>Aşağıdan bir silah seç, sonra düşman hattında hedef kareye dokun.</p>';
    const T = TYPES[app.sel.kind];
    const seg = T.pattern === 'line' ? `<div class="seg" role="group" aria-label="Yön"><button type="button" data-orient="row" aria-pressed="${app.orient === 'row'}">Satır</button><button type="button" data-orient="col" aria-pressed="${app.orient === 'col'}">Sütun</button></div>` : '';
    const info = `<p><b>${T.weapon}</b> · ${app.aim ? `Hedef: ${aimLabel()}. Aynı kareye tekrar dokun ya da ${T.scan ? 'tara' : 'ateş et'}.` : T.desc}</p>`;
    return `${warn || info}${seg}<button type="button" class="btn${app.aim ? ' fire' : ''}" id="fireBtn"${app.aim ? '' : ' disabled'}>${T.scan ? 'Tara' : 'Ateş'}</button>`;
  }

  function armsHTML(my, opts) {
    const ok = new Set(opts.map((o) => o.sid + ':' + o.kind));
    const card = (s, kind, extra) => {
      const T = TYPES[kind];
      let state = 'Hazır', cls = 'arm' + (extra || '');
      if (!s.alive) { state = 'Düştü'; cls += ' out'; }
      else if (kind !== 'tabanca' && T.once && s.used) { state = 'Kullanıldı'; cls += ' spent'; }
      else if (kind !== 'tabanca' && s.cd > 0) { state = `${s.cd} tur bekler`; cls += ' cool'; }
      const sel = !!(app.sel && app.sel.sid === s.id && app.sel.kind === kind);
      if (sel) cls += ' sel';
      return `<li><button type="button" class="${cls}" data-sid="${s.id}" data-kind="${kind}" aria-pressed="${sel}"${ok.has(s.id + ':' + kind) ? '' : ' disabled'}>${D.tile(s.type, 'ally' + (s.alive ? '' : ' dead'))}<span class="arm-t"><b>${T.weapon}</b><small>${kind === 'tabanca' ? 'Son direniş · ' + TYPES[s.type].name : T.name}</small></span>${D.patMini(kind)}<span class="pill">${state}</span></button></li>`;
    };
    let h = my.soldiers.map((s) => card(s, s.type)).join('');
    const alive = my.soldiers.filter((s) => s.alive);
    if (alive.length === 1) h += card(alive[0], 'tabanca', ' last');
    return h;
  }

  function renderBattle() {
    const g = app.game, me = app.viewer, my = g.sides[me], foe = g.sides[1 - me];
    const myTurn = g.turn === me && g.winner === null && !app.busy;
    const last = g.log[g.log.length - 1];
    let news = g.turn === me && !last ? 'İlk atış senden. Aşağıdan bir silah seç.' : '', cls = '';
    if (last) { news = D.logText(g, last); cls = (last.a === me ? 'mine ' : '') + (last.kills.length ? 'kill' : last.hint ? 'info' : ''); }
    screen.innerHTML = `
    <section class="battle">
      <div class="panel">
        <p class="news ${cls}" aria-live="polite">${news}</p>
        <div class="ph"><h2>${g.mode === 'pve' ? 'Düşman hattı' : `Oyuncu ${2 - me} hattı`}</h2>
          <ul class="foe-roster" aria-label="Rakip kadrosu">${foe.soldiers.map((s) => `<li class="${s.alive ? '' : 'out'}" title="${TYPES[s.type].name}${s.alive ? '' : ' · düştü'}">${D.tile(s.type, 'foe' + (s.alive ? '' : ' dead'))}</li>`).join('')}</ul></div>
        ${D.boardHTML(app, 1 - me, 'target')}
        <div class="aimbar" id="aimbar">${aimbarHTML(myTurn)}</div>
        <ul class="arms" id="arms">${armsHTML(my, myTurn ? O.options(my) : [])}</ul>
      </div>
      <div class="panel">
        <h2 class="sub">${g.mode === 'pve' ? 'Senin hattın' : `Oyuncu ${me + 1} · senin hattın`}</h2>
        ${D.boardHTML(app, me, 'own')}
        <h2 class="sub">Cephe kaydı</h2>
        <ol class="log">${g.log.slice(-10).reverse().map((r) => `<li class="${r.a === me ? 'mine' : 'theirs'}"><span class="rd">T${r.round}</span>${D.logText(g, r)}</li>`).join('') || '<li>Henüz atış yok.</li>'}</ol>
      </div>
    </section>`;
    app.fx = null;
    setStatus();
    paintPreview(null);
  }

  function refreshControls(focusSel) {
    const g = app.game, my = g.sides[app.viewer];
    const myTurn = g.turn === app.viewer && g.winner === null && !app.busy;
    $('#aimbar').innerHTML = aimbarHTML(myTurn);
    $('#arms').innerHTML = armsHTML(my, myTurn ? O.options(my) : []);
    $('.board.target').classList.toggle('scan', !!(app.sel && TYPES[app.sel.kind].scan));
    if (focusSel) { const b = $(`#arms [data-sid="${focusSel.sid}"][data-kind="${focusSel.kind}"]`); if (b) b.focus({ preventScroll: true }); }
    paintPreview(null);
  }

  let hover = null;
  function paintPreview(r, c) {
    if (r !== undefined) hover = r == null ? null : [r, c];
    const board = $('.board.target');
    if (!board) return;
    board.querySelectorAll('.pv, .pv-lock').forEach((el) => el.classList.remove('pv', 'pv-lock'));
    if (!app.sel) return;
    const pat = TYPES[app.sel.kind].pattern;
    const mark = (rr, cc, cl) => O.cellsFor(pat, rr, cc, app.orient).forEach(([a, b]) => { const el = board.querySelector(`[data-r="${a}"][data-c="${b}"]`); if (el) el.classList.add(cl); });
    if (app.aim) mark(app.aim[0], app.aim[1], 'pv-lock');
    if (hover) mark(hover[0], hover[1], 'pv');
  }

  function render() {
    if (app.view === 'menu') renderMenu();
    else if (app.view === 'place') renderPlace();
    else renderBattle();
    setStatus();
  }
  function show(view) { app.view = view; render(); window.scrollTo(0, 0); }

  /* ---------- Akış ---------- */

  function startGame(mode, li) {
    clearTimeout(timer);
    const g = O.newGame(mode, li);
    if (mode === 'pve') O.placeRandom(g.sides[1], LEVELS[li].brain >= 4);
    Object.assign(app, { game: g, placeIdx: 0, pick: 0, sel: null, aim: null, orient: 'row', busy: false, viewer: 0, fx: null, note: '', lastRes: null });
    cover.hidden = true;
    show('place');
  }

  function goMenu() {
    clearTimeout(timer);
    cover.hidden = true;
    leaveArmed = false;
    Object.assign(app, { game: null, sel: null, aim: null, busy: false, fx: null });
    show('menu');
  }

  function askLeave() {
    const live = app.view !== 'menu' && app.game && app.game.winner === null;
    if (!live || leaveArmed) return goMenu();
    leaveArmed = true;
    menuBtn.textContent = 'Maçı bırak?';
    menuBtn.classList.add('primary');
    setTimeout(() => { leaveArmed = false; setStatus(); }, 3000);
  }

  function showCover(eyebrow, title, text, go) {
    coverNext = go;
    cover.innerHTML = `<div class="cover-in"><p class="eyebrow">${eyebrow}</p><h2>${title}</h2><p>${text}</p><button type="button" class="btn primary" id="coverGo">Hazırım</button></div>`;
    cover.hidden = false;
    $('#coverGo').focus();
  }
  function coverGo() { cover.hidden = true; const go = coverNext; coverNext = null; if (go) go(); }

  function placeClick(b) {
    const side = app.game.sides[app.placeIdx];
    if (b.dataset.chip != null) { const id = +b.dataset.chip; app.pick = app.pick === id ? null : id; return renderPlace(); }
    if (b.id === 'shuffle') { O.placeRandom(side, false); app.pick = null; return renderPlace(); }
    if (b.id === 'clearPlace') { side.soldiers.forEach((s) => { s.r = -1; s.c = -1; }); app.pick = 0; return renderPlace(); }
    if (b.id === 'ready') return placeDone();
    if (b.dataset.r == null) return;
    const r = +b.dataset.r, c = +b.dataset.c, occ = O.soldierAt(side, r, c);
    if (app.pick == null) { if (occ) { occ.r = -1; occ.c = -1; app.pick = occ.id; } }
    else {
      const s = side.soldiers[app.pick];
      if (occ && occ !== s) { occ.r = s.r; occ.c = s.c; }
      s.r = r; s.c = c;
      const nx = side.soldiers.find((x) => x.r < 0);
      app.pick = nx ? nx.id : null;
    }
    renderPlace();
    const cell = $(`.board.place [data-r="${r}"][data-c="${c}"]`);
    if (cell) cell.focus({ preventScroll: true });
  }

  function placeDone() {
    const g = app.game;
    app.sel = null; app.aim = null;
    if (g.mode === 'pve') { app.viewer = 0; return show('battle'); }
    screen.innerHTML = '';
    if (app.placeIdx === 0) {
      app.placeIdx = 1; app.pick = 0;
      return showCover('Cihazı devret', 'Oyuncu 2', 'Oyuncu 1 hazır. Şimdi Oyuncu 2 askerlerini yerleştirecek; Oyuncu 1 ekrana bakmasın.', () => show('place'));
    }
    app.viewer = 0;
    showCover('Maç başlıyor', 'Oyuncu 1', 'İki taraf da hazır. İlk atış Oyuncu 1’den; cihazı ona ver.', () => show('battle'));
  }

  const sameTarget = (r, c) => {
    if (!app.aim) return false;
    if (TYPES[app.sel.kind].pattern === 'line') return app.orient === 'col' ? app.aim[1] === c : app.aim[0] === r;
    return app.aim[0] === r && app.aim[1] === c;
  };

  function flashNote(msg) {
    app.note = msg;
    refreshControls();
    clearTimeout(noteTimer);
    noteTimer = setTimeout(() => { app.note = ''; if (app.view === 'battle' && $('#aimbar')) refreshControls(); }, 2400);
  }

  function aimAt(r, c) {
    const g = app.game;
    if (g.turn !== app.viewer || app.busy || g.winner !== null) return;
    if (!app.sel) return flashNote('Önce aşağıdan bir silah seç.');
    if (!O.validTarget(g.sides[1 - app.viewer], app.sel.kind, r, c, app.orient)) return flashNote('Bu alanın tamamına zaten ateş edildi. Başka bir kare seç.');
    if (sameTarget(r, c)) return doFire();
    app.aim = [r, c];
    app.note = '';
    refreshControls();
  }

  function battleClick(b) {
    const g = app.game;
    if (b.dataset.kind) {
      const sel = { sid: +b.dataset.sid, kind: b.dataset.kind };
      app.sel = app.sel && app.sel.sid === sel.sid && app.sel.kind === sel.kind ? null : sel;
      app.aim = null; app.note = '';
      return refreshControls(sel);
    }
    if (b.dataset.orient) {
      app.orient = b.dataset.orient;
      if (app.aim && !O.validTarget(g.sides[1 - app.viewer], app.sel.kind, app.aim[0], app.aim[1], app.orient)) app.aim = null;
      return refreshControls();
    }
    if (b.id === 'fireBtn') return doFire();
    if (b.dataset.r != null && b.closest('.board.target')) aimAt(+b.dataset.r, +b.dataset.c);
  }

  function fxFor(res) {
    if (!res || res.kind === 'skip') return null;
    const def = app.game.sides[1 - res.a];
    return {
      side: 1 - res.a,
      cells: res.cells.map(([r, c]) => r * N + c),
      kills: res.kills.map((id) => def.soldiers[id].r * N + def.soldiers[id].c),
      scan: !!TYPES[res.kind].scan,
    };
  }

  function doFire() {
    const g = app.game, a = app.viewer;
    if (!app.sel || !app.aim || g.turn !== a || app.busy || g.winner !== null) return;
    const res = O.fire(g, a, app.sel, app.aim[0], app.aim[1], app.orient);
    app.sel = null; app.aim = null; app.note = '';
    app.lastRes = res;
    app.fx = fxFor(res);
    app.busy = true;
    renderBattle();
    if (g.winner !== null) return later(showResult, 1300);
    if (g.mode === 'pve') return later(aiTurn, T_AI);
    later(handoff, 1500);
  }

  function aiTurn() {
    const g = app.game;
    if (!g || app.view !== 'battle' || g.winner !== null || g.turn !== 1) return;
    const mv = O.aiChoose(g, 1, LEVELS[g.levelIndex].brain);
    const res = mv ? O.fire(g, 1, mv.choice, mv.r, mv.c, mv.orient) : O.skip(g, 1);
    app.fx = fxFor(res);
    if (g.winner !== null) { renderBattle(); return later(showResult, 1400); }
    if (!O.options(g.sides[0]).length) { O.skip(g, 0); renderBattle(); return later(aiTurn, T_AI); }
    app.busy = false;
    renderBattle();
  }

  function handoff() {
    const g = app.game;
    if (!g || g.winner !== null) return;
    if (!O.options(g.sides[g.turn]).length) O.skip(g, g.turn);
    if (g.turn === app.viewer) { app.busy = false; return renderBattle(); }
    const next = g.turn;
    Object.assign(app, { viewer: next, busy: false, sel: null, aim: null, fx: fxFor(app.lastRes) });
    screen.innerHTML = '';
    setStatus();
    const lastText = app.lastRes ? D.logText(g, app.lastRes) : '';
    showCover('Cihazı devret', `Oyuncu ${next + 1}`, `Sıra sende; rakip ekrana bakmasın. Son atış: ${lastText}`, () => show('battle'));
  }

  function showResult() {
    const g = app.game;
    if (!g || g.winner === null) return;
    const pve = g.mode === 'pve', won = g.winner === 0;
    const left = g.sides[g.winner].soldiers.filter((s) => s.alive).length;
    if (pve && won) saveDone(g.levelIndex);
    const hasNext = pve && won && g.levelIndex < LEVELS.length - 1;
    const title = pve ? (won ? 'Zafer' : 'Hat düştü') : `Oyuncu ${g.winner + 1} kazandı`;
    const text = pve
      ? (won ? `${LEVELS[g.levelIndex].name} dağıldı, ${left} askerin ayakta.` + (hasNext ? ` Sıradaki rakip daha güçlü: ${LEVELS[g.levelIndex + 1].name}.` : ' Kampanyayı bitirdin.') : `Bütün askerlerin düştü. Düşmanın ${left} askeri ayakta kaldı.`)
      : `${g.round} turda, ${left} asker ayakta kalarak kazandı.`;
    cover.innerHTML = `<div class="cover-in${pve && !won ? ' lose' : ''}"><p class="eyebrow">${pve ? `Bölüm ${g.levelIndex + 1}` : 'İki kişi'} · ${g.round} tur</p><h2>${title}</h2><p>${text}</p>
      <div class="row-btns">${hasNext ? '<button type="button" class="btn primary" data-act="next">Sonraki bölüm</button>' : ''}<button type="button" class="btn${hasNext ? '' : ' primary'}" data-act="again">Tekrar oyna</button><button type="button" class="btn ghost" data-act="board">Tahtayı gör</button><button type="button" class="btn ghost" data-act="menu">Menü</button></div></div>`;
    cover.hidden = false;
    app.busy = false;
    setStatus();
    const f = cover.querySelector('.btn');
    if (f) f.focus();
  }

  function resultAct(act) {
    const g = app.game;
    cover.hidden = true;
    if (act === 'next' && g) return startGame('pve', g.levelIndex + 1);
    if (act === 'again' && g) return startGame(g.mode, g.levelIndex);
    if (act === 'board' && g) return show('battle');
    goMenu();
  }

  /* ---------- Olaylar ---------- */

  document.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b || b.disabled) return;
    if (b.id === 'home' || b.id === 'menuBtn') return askLeave();
    if (b.id === 'coverGo') return coverGo();
    if (b.dataset.act) return resultAct(b.dataset.act);
    if (b.dataset.level) return startGame('pve', +b.dataset.level);
    if (b.id === 'startPvp') return startGame('pvp', -1);
    if (app.view === 'place') return placeClick(b);
    if (app.view === 'battle') return battleClick(b);
  });

  screen.addEventListener('pointerover', (e) => {
    const c = e.target.closest('.board.target .cell');
    if (c) paintPreview(+c.dataset.r, +c.dataset.c);
  });
  screen.addEventListener('pointerleave', () => paintPreview(null));
  screen.addEventListener('focusin', (e) => {
    const c = e.target.closest('.board.target .cell');
    if (c) paintPreview(+c.dataset.r, +c.dataset.c);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && app.view === 'battle' && app.sel) { app.sel = null; app.aim = null; refreshControls(); }
  });

  /* ---------- Açılış (sayfa güncellenince maç kaldığı yerden sürer) ---------- */

  function start(data) {
    const saved = data && data.app;
    if (saved && saved.view && (saved.view === 'menu' || saved.game)) Object.assign(app, saved, { busy: false, fx: null, note: '' });
    const hot = window.claude && window.claude.hot;
    if (hot && typeof hot.snapshot === 'function') {
      try { hot.snapshot(() => ({ app: Object.assign({}, app, { fx: null }) })); } catch (e) { /* güncelleme kancası yoksa sorun değil */ }
    }
    render();
    const g = app.game;
    if (app.view !== 'battle' || !g || g.winner !== null) return;
    if (g.mode === 'pve' && g.turn === 1) { app.busy = true; renderBattle(); later(aiTurn, T_AI); }
    else if (g.mode === 'pvp' && g.turn !== app.viewer) handoff();
  }

  const hot = window.claude && window.claude.hot;
  if (hot && hot.ready) hot.ready(start); else start((hot && hot.data) || {});
})();
